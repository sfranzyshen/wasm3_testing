/* Use the WASI libc fcntl implementation bits. */
