/* Use the WASI libc ioctl implementation bits. */
